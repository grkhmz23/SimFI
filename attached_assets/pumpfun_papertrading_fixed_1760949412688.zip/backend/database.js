// backend database.js (fixed)
