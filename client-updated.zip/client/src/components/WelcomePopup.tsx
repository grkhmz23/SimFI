import { useState, useEffect } from 'react';
import { X } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface WelcomePopupProps {
  imageSrc?: string;
  storageKey?: string;
  delay?: number;
  showOncePerSession?: boolean;
}

export function WelcomePopup({
  imageSrc = '/poop-up.png',
  storageKey = 'simfi-welcome-popup-seen',
  delay = 500,
  showOncePerSession = false,
}: WelcomePopupProps) {
  const [isOpen, setIsOpen] = useState(false);

  useEffect(() => {
    const storage = showOncePerSession ? sessionStorage : localStorage;
    const hasSeen = storage.getItem(storageKey);
    
    if (!hasSeen) {
      const timer = setTimeout(() => {
        setIsOpen(true);
      }, delay);
      
      return () => clearTimeout(timer);
    }
  }, [storageKey, delay, showOncePerSession]);

  const handleClose = () => {
    setIsOpen(false);
    const storage = showOncePerSession ? sessionStorage : localStorage;
    storage.setItem(storageKey, 'true');
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="fixed inset-0 z-[100] bg-black/70 backdrop-blur-sm"
            onClick={handleClose}
          />
          
          {/* Popup */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            transition={{ type: "spring", damping: 25, stiffness: 300 }}
            className="fixed inset-0 z-[101] flex items-center justify-center p-4 pointer-events-none"
          >
            <div className="relative pointer-events-auto max-w-lg w-full">
              {/* Glow effect - PRIMARY GREEN */}
              <div className="absolute -inset-1 bg-gradient-to-r from-primary via-primary/60 to-primary rounded-2xl blur-lg opacity-60 animate-pulse" />
              
              {/* Main container */}
              <div className="relative bg-card border-2 border-primary/50 rounded-2xl overflow-hidden shadow-2xl shadow-primary/20">
                {/* Close button */}
                <button
                  onClick={handleClose}
                  className="absolute top-3 right-3 z-10 w-10 h-10 flex items-center justify-center rounded-full bg-background/90 border-2 border-primary/40 text-foreground hover:bg-primary hover:text-primary-foreground hover:border-primary transition-all duration-200 group shadow-lg"
                  aria-label="Close popup"
                >
                  <X className="h-5 w-5 group-hover:rotate-90 transition-transform duration-200" />
                </button>
                
                {/* Image */}
                <img
                  src={imageSrc}
                  alt="Welcome to SimFi"
                  className="w-full h-auto object-contain"
                  onError={(e) => {
                    console.error('Popup image failed to load:', imageSrc);
                    handleClose();
                  }}
                />
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}

export default WelcomePopup;
